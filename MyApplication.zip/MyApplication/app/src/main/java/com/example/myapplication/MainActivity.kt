package com.example.myapplication

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.RecyclerTouchListener.OnRowClickListener
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.widget.Button
import android.widget.RemoteViews
import androidx.recyclerview.widget.LinearLayoutManager


class MainActivity : AppCompatActivity() {

    private var recyclerviewAdapter: RecyclerviewAdapter? = null
    private var touchListener: RecyclerTouchListener? = null
    private lateinit var recyclerView: RecyclerView
    private lateinit var notificationAdapter: NotificationAdapter
    lateinit var notificationManager: NotificationManager
    lateinit var notificationChannel: NotificationChannel
    lateinit var builder: Notification.Builder
    private val channelId = "i.apps.notifications"
    private val description = "Test notification"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // accessing button
        val btn = findViewById<Button>(R.id.btn)

        // it is a class to notify the user of events that happen.
        // This is how you tell the user that something has happened in the
        // background.





        recyclerView = findViewById(R.id.recyclerview)

        recyclerviewAdapter = RecyclerviewAdapter(this)
//        notificationAdapter = NotificationAdapter()
//        recyclerView.adapter = notificationAdapter
//        val notifications = listOf(
//            Notification("John Doe liked your post"),
//            Notification("Jane Smith commented on your photo"),
//            Notification("New message from Alex"),
//            Notification("You have a new follower")
//        )
//        notificationAdapter.submitList(notifications)
        recyclerView = findViewById(R.id.notificationRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize the adapter
        notificationAdapter = NotificationAdapter()

        // Set the adapter to the RecyclerView
        recyclerView.adapter = notificationAdapter

        // Add sample notifications to the adapter
        val notifications = listOf(
            Notification("John Doe liked your post"),
            Notification("Jane Smith commented on your photo"),
            Notification("New message from Alex"),
            Notification("You have a new follower")
        )
        notificationAdapter.submitList(notifications)
        val taskList: MutableList<Task> = ArrayList()
        var task = Task("Buy Dress", "Buy Dress at Shoppershop for coming functions")
        taskList.add(task)
        task = Task("Go For Walk", "Wake up 6AM go for walking")
        taskList.add(task)
        task = Task("Office Work", "Complete the office works on Time")
        taskList.add(task)
        task = Task("watch Repair", "Give watch to service center")
        taskList.add(task)
        task = Task("Recharge Mobile", "Recharge for 10$ to my **** number")
        taskList.add(task)
        task = Task("Read book", "Read android book completely")
        taskList.add(task)
        recyclerviewAdapter!!.setTaskList(taskList)
        recyclerView?.setAdapter(recyclerviewAdapter)
        touchListener = RecyclerTouchListener(this, recyclerView)
        touchListener!!
            .setClickable(object : OnRowClickListener {
                override fun onRowClicked(position: Int) {
                    Toast.makeText(applicationContext, taskList[position].name, Toast.LENGTH_SHORT)
                        .show()
                }

                override fun onIndependentViewClicked(independentViewID: Int, position: Int) {}
            })
            .setSwipeOptionViews(R.id.delete_task, R.id.edit_task)
            .setSwipeable(
                R.id.rowFG, R.id.rowBG
            ) { viewID, position ->
                when (viewID) {
                    R.id.delete_task -> {
                        taskList.removeAt(position)
                        recyclerviewAdapter!!.setTaskList(taskList)
                    }

                    R.id.edit_task -> Toast.makeText(
                        applicationContext,
                        "Edit Not Available",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        recyclerView?.addOnItemTouchListener(touchListener!!)
    }

    public override fun onResume() {
        super.onResume()
        recyclerView!!.addOnItemTouchListener(touchListener!!)
    }
}