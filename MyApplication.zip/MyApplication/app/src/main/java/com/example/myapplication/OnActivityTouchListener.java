package com.example.myapplication;
import android.view.MotionEvent;
public interface OnActivityTouchListener {
    void getTouchCoordinates(MotionEvent ev);
}
