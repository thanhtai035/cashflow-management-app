package com.example.myapplication

data class Notification(val message: String)